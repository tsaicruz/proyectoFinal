drop database if exists disqueria; 
create database disqueria;
use disqueria;


-- borrar cliente disco sucurusalstock sucursal
drop table if exists cliente;
drop table if exists sucursalStock;
drop table if exists sucursal;
drop table if exists disco;


-- Base de datos de una disqueria.


-- Tabla de disco 
create table disco (
    id int AUTO_INCREMENT PRIMARY KEY,
    album VARCHAR(50) not null,
    artista VARCHAR(50) not null,
    genero VARCHAR(50) not null,
    anio int not null,
    precio double not null,
    tipodisco enum('VINILO', 'CD', 'DVD', 'CASSETE')
);

-- Tabla del cliente
create table cliente (
    id int AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(25) not null,
    apellido VARCHAR(25) not null,
    edad int not null,
    idSucursal int not null    
);

-- Tabla de stock de sucursales

create table sucursalStock(
    id int AUTO_INCREMENT PRIMARY KEY,
    idSucursal int not null,
    idDisco int not null,
    stock int 
);

-- Tabla de Sucursales 
create table sucursal(
    id int AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) not null,
    direccion VARCHAR(50) not null,
    stock int not null
);

alter table sucursalStock
add constraint FK_sucursalStock_iddisco foreign key(idDisco)  references disco(id);
alter table sucursalStock
add constraint FK_sucursalStock_idsucursal foreign key(idSucursal)  references sucursal(id);
alter table cliente
add constraint FK_cliente_idsucursal foreign key(idSucursal)  references sucursal(id);


show databases;
select * from sucursal;
select * from sucursalStock;
select * from disco;
select * from cliente;


