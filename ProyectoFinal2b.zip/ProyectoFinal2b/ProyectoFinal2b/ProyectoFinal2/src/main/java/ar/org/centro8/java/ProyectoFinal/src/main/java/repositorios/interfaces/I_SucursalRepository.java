package ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.centro8.java.ProyectoFinal.src.main.java.entities.Sucursal;

public interface I_SucursalRepository {
    void save(Sucursal sucursal);

    void remove(Sucursal sucursal);

    void update(Sucursal sucursal);

    default Sucursal getById(int id) {
        return getAll()
                .stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(new Sucursal());
    }

    List<Sucursal> getAll();

    default List<Sucursal> getLikeNombList(String nombre) {
        if (nombre == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(c -> c.getNombre() != null)
                .filter(c -> c.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .collect(Collectors.toList());
    }

}
