package ar.org.centro8.java.ProyectoFinal.src.main.java.entities;

public class SucursalStock {
    private int id;
    private int idSucursal;
    private int idDisco;
    private int stock;

    public SucursalStock() {

    }

    public SucursalStock(int stock) {
        this.stock = stock;
    }

    public SucursalStock(int idSucursal, int idDisco, int stock) {
        this.idSucursal = idSucursal;
        this.idDisco = idDisco;
        this.stock = stock;
    }

    public SucursalStock(int id, int idSucursal, int idDisco, int stock) {
        this.id = id;
        this.idSucursal = idSucursal;
        this.idDisco = idDisco;
        this.stock = stock;
    }

    @Override
    public String toString() {
        return "SucursalStock [id=" + id + ", idDisco=" + idDisco + ", idSucursal=" + idSucursal + ", stock=" + stock
                + "]";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdSucursal() {
        return idSucursal;
    }

    public void setIdSucursal(int idSucursal) {
        this.idSucursal = idSucursal;
    }

    public int getIdDisco() {
        return idDisco;
    }

    public void setIdDisco(int idDisco) {
        this.idDisco = idDisco;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

}
