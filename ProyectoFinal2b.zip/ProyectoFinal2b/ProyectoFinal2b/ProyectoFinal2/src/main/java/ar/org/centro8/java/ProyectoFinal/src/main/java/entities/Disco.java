package ar.org.centro8.java.ProyectoFinal.src.main.java.entities;

import ar.org.centro8.java.ProyectoFinal.src.main.java.enums.Tipodisco;

public class Disco {
    private int id;
    private String album;
    private String artista;
    private String genero;
    private int anio;
    private double precio;
    private Tipodisco tipodisco;

    public Disco() {
    }

    public Disco(int id, String album, String artista, String genero, int anio, double precio, Tipodisco tipodisco) {
        this.id = id;
        this.album = album;
        this.artista = artista;
        this.genero = genero;
        this.anio = anio;
        this.precio = precio;
        this.tipodisco = tipodisco;
    }

    public Disco(String album, String artista, String genero, int anio, double precio, Tipodisco tipodisco) {
        this.album = album;
        this.artista = artista;
        this.genero = genero;
        this.anio = anio;
        this.precio = precio;
        this.tipodisco = tipodisco;
    }

    @Override
    public String toString() {
        return "Disco [album=" + album + ", anio=" + anio + ", artista=" + artista + ", genero=" + genero + ", id=" + id
                + ", precio=" + precio + ", tipodisco=" + tipodisco + "]";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Tipodisco getTipodisco() {
        return tipodisco;
    }

    public void setTipodisco(Tipodisco tipodisco) {
        this.tipodisco = tipodisco;
    }

}
