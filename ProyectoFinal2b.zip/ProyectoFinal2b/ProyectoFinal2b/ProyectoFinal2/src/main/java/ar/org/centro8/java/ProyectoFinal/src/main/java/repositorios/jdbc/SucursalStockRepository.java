package ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.java.ProyectoFinal.src.main.java.entities.SucursalStock;
import ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.interfaces.I_SucursalStockRepository;

public class SucursalStockRepository implements I_SucursalStockRepository {

    private Connection conn;

    public SucursalStockRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<SucursalStock> getAll() {
        List<SucursalStock> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from sucursalStock")) {
            while (rs.next()) {
                list.add(
                        new SucursalStock(
                                rs.getInt("id"),
                                rs.getInt("idSucursal"),
                                rs.getInt("idDisco"),
                                rs.getInt("stock")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;

    }

    @Override
    public void remove(SucursalStock sucursalstock) {
        if (sucursalstock == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from sucursalStock where id = ?")) {
            ps.setInt(1, sucursalstock.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void save(SucursalStock sucursalstock) {
        if (sucursalstock == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into sucursalStock (idSucursal, idDisco, stock) values (?,?,?,? )",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, sucursalstock.getId());
            ps.setInt(2, sucursalstock.getIdSucursal());
            ps.setInt(3, sucursalstock.getIdDisco());
            ps.setInt(4, sucursalstock.getStock());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                sucursalstock.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(SucursalStock sucursalstock) {
        if (sucursalstock == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update sucursal set id=?, idSucursal=?, id=?, stock=?, where id=?")) {
            ps.setInt(1, sucursalstock.getIdSucursal());
            ps.setInt(2, sucursalstock.getIdDisco());
            ps.setInt(3, sucursalstock.getStock());
            ps.setInt(4, sucursalstock.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }

    }
}
