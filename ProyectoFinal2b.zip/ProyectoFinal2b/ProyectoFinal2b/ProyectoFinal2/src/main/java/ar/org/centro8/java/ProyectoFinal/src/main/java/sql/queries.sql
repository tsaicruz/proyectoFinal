
-- hacer queries que tengan varias tablas. para hacer en casa.

-- consultas 

-- buscamos cuantos clientes tiene una sucursal
select *
from sucursal
left join cliente on sucursal.id = cliente.idSucursal
where idSucursal = 2;

-- buscamos en que sucursal esta cierto disco y cuantos stock tiene

select sucursalStock.stock, disco.artista, sucursalStock.idSucursal, sucursal.nombre
from sucursalStock
inner join disco on sucursalStock.id = disco.id
inner join sucursal on sucursalStock.id = sucursal.id
where iddisco= 3;
;

-- buscamos el nombre y el apellido de las personas que estan en una sucursal
select cliente.nombre, cliente.apellido, sucursal.nombre, sucursal.direccion
from cliente
inner join sucursal on cliente.idSucursal = sucursal.id
where idsucursal = 5 ;

-- sumamos el total de stock de sucursalStock y Sucursales
select distinct sucursal.stock + sucursalStock.stock as stocktotal,
sucursal.nombre 
from sucursalStock
inner join sucursal on sucursal.id = sucursalStock.idsucursal
group by sucursal.nombre
order by stocktotal;

-- restamos de sucursalStock un disco y buscamos el nombre del disco 
select sucursalStock.stock - 1 as stock,
disco.artista, disco.album
from sucursalStock
inner join disco on sucursalStock.id = disco.id
where iddisco = 5;

-- buscamos los clientes que empiecen con la letra que querramos y en que sucursales estan 
select *
from sucursal
left join cliente on sucursal.id = cliente.idSucursal
where cliente.nombre rlike '^j';

 
SET SQL_SAFE_UPDATES = 0;