package repositorios.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import entities.Sucursal;
import repositorios.interfaces.I_SucursalRepository;

public class SucursalRepository implements  I_SucursalRepository {
    private Connection conn;

    public SucursalRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Sucursal> getAll() {
        List<Sucursal> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from sucursal")) {
            while (rs.next()) {
                list.add(
                        new Sucursal(
                                rs.getInt("id"),
                                rs.getString("nombre"),
                                rs.getString("direccion"),
                                rs.getInt("stock")
                               ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void remove(Sucursal sucursal) {
        if (sucursal == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from sucursal where id=?")) {
            ps.setInt(1, sucursal.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void save(Sucursal sucursal) {
        if (sucursal == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into sucursal (nombre, direccion, stock) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, sucursal.getNombre());
            ps.setString(2, sucursal.getDireccion());
            ps.setInt(3, sucursal.getStock());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                sucursal.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Sucursal sucursal) {
        if (sucursal == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
            "update sucursal set nombre=?, direccion=?, stock=?, where id=?" )) {
            ps.setString(1, sucursal.getNombre());
            ps.setString(2, sucursal.getDireccion());
            ps.setInt(3, sucursal.getStock());
            ps.setInt(4, sucursal.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
