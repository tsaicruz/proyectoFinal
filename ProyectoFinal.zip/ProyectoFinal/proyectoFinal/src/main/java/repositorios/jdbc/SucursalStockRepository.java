package repositorios.jdbc;

public class SucursalStockRepository {

}
