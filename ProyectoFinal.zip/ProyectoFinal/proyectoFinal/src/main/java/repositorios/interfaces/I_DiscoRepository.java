package repositorios.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import entities.Disco;

public interface I_DiscoRepository {
    void save(Disco disco);
    void remove(Disco disco);
    void update(Disco disco);

    default Disco getById(int id) {
        return getAll()
                .stream()
                .filter(d -> d.getId() == id)
                .findFirst()
                .orElse(new Disco());
    }

    List<Disco> getAll();

    default List<Disco> getLikeAlbum(String album) {
        if (album == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(d -> d.getAlbum() != null)
                .filter(d -> d.getAlbum().toLowerCase().contains(album.toLowerCase()))
                .collect(Collectors.toList());
    }

}
