package repositorios.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import entities.SucursalStock;

public interface I_SucursalStockRepository {

    void save(SucursalStock sucust);

    void remove(SucursalStock sucust);

    void update(SucursalStock sucust);

    default SucursalStock getById(int id) {
        return getAll()
                .stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(new SucursalStock());
    }

    List<SucursalStock> getAll();

    default List<SucursalStock> getLikeNombList(String nombre) {
        if (nombre == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(c -> c.getNombre() != null)
                .filter(c -> c.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .collect(Collectors.toList());
    }

}
