package entities;

public class SucursalStock {
    private int id;
    private int idSucursal;
    private int idDisco;
    private String nombre;
    private String direccion;
    private int stock;

    public SucursalStock() {
    }

    public SucursalStock(int id, int idSucursal, int idDisco, String nombre, String direccion, int stock) {
        this.id = id;
        this.idSucursal = idSucursal;
        this.idDisco = idDisco;
        this.nombre = nombre;
        this.direccion = direccion;
        this.stock = stock;
    }

    @Override
    public String toString() {
        return "SucursalStock [direccion=" + direccion + ", id=" + id + ", idDisco=" + idDisco + ", idSucursal="
                + idSucursal + ", nombre=" + nombre + ", stock=" + stock + "]";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdSucursal() {
        return idSucursal;
    }

    public void setIdSucursal(int idSucursal) {
        this.idSucursal = idSucursal;
    }

    public int getIdDisco() {
        return idDisco;
    }

    public void setIdDisco(int idDisco) {
        this.idDisco = idDisco;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

}
