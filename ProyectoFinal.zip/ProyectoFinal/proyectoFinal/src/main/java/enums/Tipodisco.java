package enums;

public enum Tipodisco {
    VINILO,
    CD,
    DVD,
    CASSETE;
}
