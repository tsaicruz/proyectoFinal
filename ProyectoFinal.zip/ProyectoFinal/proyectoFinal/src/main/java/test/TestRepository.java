package test;

import org.mariadb.jdbc.Connection;

import connections.Connector;
import entities.Cliente;
import entities.Disco;
import entities.Sucursal;
import enums.Tipodisco;
import repositorios.interfaces.I_ClienteRepository;
import repositorios.interfaces.I_DiscoRepository;
import repositorios.interfaces.I_SucursalRepository;
import repositorios.jdbc.ClienteRepository;
import repositorios.jdbc.DiscoRepository;
import repositorios.jdbc.SucursalRepository;


public class TestRepository{
    public static void main(String[] args){
        Connection conn=(Connection) Connector.getConnection();
        I_DiscoRepository disc = new DiscoRepository(conn);

        Disco disco = new Disco("AFLLS", "aurora", "pop", 5698, Tipodisco.CASSETE);
        disc.save(disco);
        System.out.println(disco);

        // disc.remove(disc.getById(3)); preguntar porque no funciona

        disco=disc.getById(11);
        disco.setTipodisco(Tipodisco.DVD);
        disc.update(disco);
        disc.getAll().forEach(System.out::println);
        System.out.println("*******************************************************************************");

        disc.getLikeAlbum("arr").forEach(System.out::println);
       
        System.out.println("*******************************************************************************");

        I_ClienteRepository cl = new ClienteRepository(conn);
        Cliente cliente = new Cliente("Carlin", "Ga", 25, 5);
        cl.save(cliente);
        System.out.println(cliente);
        cl.remove(cl.getById(2));
        cliente = cl.getById(3);
        cliente.setNombre("Maria");
        cl.update(cliente);
        cl.getAll().forEach(System.out::println);
        System.out.println("*******************************************************************************");


        I_SucursalRepository sc = new SucursalRepository(conn);
        Sucursal sucursal = new Sucursal("Suquitruki", "Suculitas 1234", 52);
        sc.save(sucursal);
        System.out.println(sucursal);
        // sc.remove(sc.getById(5)); Ver porque no funciona el remove aca tampoco 
        // sucursal = sc.getById(13);  no funciona ver el porque 
        sucursal.setNombre("Hollywood discos");
        sc.update(sucursal);
        sc.getAll().forEach(System.out::println);
        











}


};